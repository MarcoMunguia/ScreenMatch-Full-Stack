package com.aluracursos.screenmatch.dto;

public record EpisodioDTO(Integer temporada,
         String titulo,
         Integer numeroEpisodio) {
}
